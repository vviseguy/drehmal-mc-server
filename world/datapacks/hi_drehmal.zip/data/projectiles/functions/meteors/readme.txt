max height to summon should be at 448 blocks, this doesn't look terrible for players at y=255 but isn't so high that it's just spending unecessary time

sounds can be heard from a maximum of 208 blocks and on average at around 200 blocks.

since entity simulation distance is always less than render distance we shouldn't run into any issues setting crash site blocks since the meteor has to be loaded to hit the ground.